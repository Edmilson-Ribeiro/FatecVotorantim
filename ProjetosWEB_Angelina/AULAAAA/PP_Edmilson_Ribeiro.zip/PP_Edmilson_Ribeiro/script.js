function cep()
let cep = document.getElementById"cep".innertext="CEP";
document.getElementById()
var api = `https://viacep.com.br/ws/${cep}/json/`;
function aceita()
    let aceita = document.getElementById"aceita".innetext = "Cadastrado com sucesso";
    document.getElementById(
    
    ).innerHTML = `Cadastrado com sucesso ${yes}.`;

      